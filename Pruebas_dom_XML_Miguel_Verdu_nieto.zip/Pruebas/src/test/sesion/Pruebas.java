package test.sesion;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import test.xml.Body;
import test.xml.Div;
import test.xml.Head;
import test.xml.Html;


public class Pruebas {

	public static void main(String[] args)
			throws IOException, ParserConfigurationException, SAXException, TransformerException, JAXBException {
		Sesion1 sesion1 = new Sesion1();
		// sesion1.recorrerCarpeta();
		try {
			Html html = (Html) sesion1.leerBytes();
			Body body = html.getBody();
			Head head = html.getHead();
			ArrayList<Div> divs = body.getDivs();

			String s = "<html><head>" + head.getValue() + "</head><body>" + body.getValue();
			for (Div d : divs) {
				s += "<div>";
				s += d.getValue();
				s += "</div>";
			}
			s += "</body></html>";
			//System.out.println(s);

			File resultado = new File("resultado.xml");
			FileWriter fw = new FileWriter(resultado);
			fw.write(s);
			fw.close();
			/*
			Class _class = Class.forName("test.xml.Html");
			Method[] properties = _class.getMethods();
			
			for (int i = 0; i < properties.length; i++) {
                Method field = properties[i];
                System.out.println(field.getName() +" > "+field.getName());
            }*/
			
			DocumentBuilderFactory factory =
			DocumentBuilderFactory.newInstance();
			factory.setIgnoringComments(true);
			factory.setIgnoringElementContentWhitespace(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			File fichero = new File("nuevo.xml");
			Document doc = (Document) builder.parse(fichero);
			Node raiz = (Node) doc.getFirstChild();
			sesion1.imprimirNodo(raiz, doc);
			fw = new FileWriter(resultado);
			fw.write(sesion1.resultado+"</html>");
			fw.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
