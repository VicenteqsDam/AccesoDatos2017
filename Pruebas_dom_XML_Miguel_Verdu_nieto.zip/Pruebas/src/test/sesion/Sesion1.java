package test.sesion;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import test.xml.Html;

public class Sesion1 {
	public void escribirSecuencial() throws IOException {
		File file = new File("fichero.txt");
		FileWriter fichero = new FileWriter(file);
		fichero.write("Texto de prueba");
		fichero.close();
	}

	public String leerSecuencial(File file) throws IOException {
		// File file = new File("cristian");
		FileReader fichero = new FileReader(file);
		char chr = (char) fichero.read();
		String resultado = "";
		while (chr != -1 && chr != 65535) {
			resultado += chr;
			// System.out.print(chr);
			chr = (char) fichero.read();
			/*
			 * int prueba = chr; System.out.println(prueba);
			 */
		}
		fichero.close();
		return resultado;
	}

	public void escribirBytes() throws IOException {
		File file = new File("ficheroBinario.bin");
		FileOutputStream fichero = new FileOutputStream(file);
		// Podriamos usar cualquier clase Serializable
		String texto = "Texto de prueba binario";
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ObjectOutputStream os = new ObjectOutputStream(out);
		os.writeObject(texto);
		os.close();
		fichero.write(out.toByteArray());
		fichero.close();
	}

	public void recorrerCarpeta() {
		File f = new File("C:\\Users\\Miguel\\Documents\\AccesoDatos2017\\Pruebas\\src\\test\\sesion\\ficheros");

		if (f.isDirectory()) {
			System.out.println(true);
			File[] files = f.listFiles();
			for (File file : files) {
				System.out.println(file.getName());
				try {
					String cadena = leerSecuencial(file);
					int pos = -1;
					for (int i = 0; i < cadena.length(); i++) {
						int num = cadena.charAt(i);
						if (num >= 48 && num <= 57) {
							pos = i;
							break;
						}
					}
					if (pos != -1) {
						RandomAccessFile rnd = new RandomAccessFile(file, "rw");
						rnd.seek(pos);
						String subCadena = cadena.substring(pos);
						rnd.writeBytes("elda" + subCadena);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		} else {

		}
	}

	public Object leerBytes() throws IOException, ClassNotFoundException {
		File file = new File("ficheroBinario.bin");
		FileInputStream fichero = new FileInputStream(file);
		ObjectInputStream is = new ObjectInputStream(fichero);
		Html texto = (Html) is.readObject();
		is.close();
		fichero.close();
		return texto;
	}
	public String resultado = "";
	public void imprimirNodo(Node raiz, Document doc){
		
		NodeList nl = raiz.getChildNodes();
		if(raiz.getFirstChild() == null){
			resultado += raiz.getNodeValue()+"</"+raiz.getParentNode().getNodeName()+">";
		}else{
			NamedNodeMap map = raiz.getAttributes();
			if(raiz.getNodeName().equals("body")){
				Node nuevo = doc.createElement("div");
				nuevo.setTextContent("div nuevo");
				
				raiz.appendChild(nuevo);
			
			}
			resultado += "<"+raiz.getNodeName();
			for(int i = 0; i < map.getLength(); i++){
				
				resultado +=" style=\""+map.item(i).getNodeValue()+"\"";
			}
			resultado+=">";
		}
		for(int i = 0; i < nl.getLength(); i++){
			//System.out.println(nl.item(i).getNodeName());
			imprimirNodo(nl.item(i), doc);
		}
		
	}

}
